<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-area-chart" aria-hidden="true"></i> <span class="title">Job Skills</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.job.skills') }}" class="nav-link "> <span class="title">List Job Skills</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.job.skill') }}" class="nav-link "> <span class="title">Add new Job Skill</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('sort.job.skills') }}" class="nav-link "> <span class="title">Sort Job Skills</span> </a> </li>
    </ul>
</li>