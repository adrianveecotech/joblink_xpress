<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="icon-wrench"></i> <span class="title">Site Settings</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('edit.site.setting') }}" class="nav-link "> <span class="title">Manage Site Settings</span> </a> </li>
    </ul>
</li>